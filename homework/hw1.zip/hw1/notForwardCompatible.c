void aFunction() {
}

// Won't compile in C++ because of these unused parameter
int main() {
    aFunction("something");
    return 0;
}
